a = int(input())
if (a<10):
    print("bebra")
